import './style.scss';
import './editor.scss';

import './register-block-type/00-demo';
import './register-block-type/01-title';
import './register-block-type/02-category';
import './register-block-type/03-icon';
import './register-block-type/04-keywords';
import './register-block-type/05-edit';
import './register-block-type/06-save';
import './register-block-type/07-attributes';
import './register-block-type/08-all';
