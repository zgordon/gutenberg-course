const icon = <svg width='20px' height='20px' viewBox='0 0 100 100' xmlns='http://www.w3.org/2000/svg'>
    <path d='m0 85h100v10h-100z' />
    <path d='m0 65h100v10h-100z' />
    <path d='m0 45h100v10h-100z' />
    <path d='m0 25h100v10h-100z' />
    <path d='m0 5h100v10h-100z' />
</svg>;

export default icon;
