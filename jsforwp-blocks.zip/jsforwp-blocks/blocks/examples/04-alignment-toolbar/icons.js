const icon =  <svg width='20px' height='20px' viewBox='0 0 100 100' xmlns='http://www.w3.org/2000/svg'>
    <path d='m37.5 87.5h62.5v12.5h-62.5z' />
    <path d='m37.5 37.5h62.5v12.5h-62.5z' />
    <path d='m0 62.5h100v12.5h-100z' />
    <path d='m0 12.5h100v12.5h-100z' />
</svg>;
export default icon;
