import './examples/13-dynamic-alt/frontend.js';
